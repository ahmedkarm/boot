$(function(){
   'use strict';
    //slider height
    var winh=$(window).height(),
    uper=$('.upper').innerHeight(),
    navh=$('.navbar ').innerHeight();
    $('.slider,.carousel-item').height(winh-(uper+navh));
    
    //shuffle
    /*$('.feat-w ul li').on('click',function(){
        $(this).addClass('active').siblings().removeClass('active')
    });*/
    $('.feat-w ul li').click(function(){
        $(this).addClass('active').siblings().removeClass('active');console.log();
        if($(this).data('class') ==='All'){
            
            $('.shu .col-md .pic').css('opacity',1);
        }else{
            $('.shu .col-md .pic').css('opacity','0.10');
            $($(this).data('class')).parent().css('opacity',1); 
        }
    });
});

















